const startproject = document.getElementById('startproject')
if (startproject) {
    startproject.addEventListener('click', () => {
        location.href = 'signup.html'
    })
}

const getstarted = document.getElementById('getstarted')
if (getstarted) {
    getstarted.addEventListener('click', () => {
        location.href = 'ourportfolio.html'
    })
}

let Btn = document.querySelector('#signup1')
if (Btn) {
    Btn.addEventListener('click', () => {
        location.href = '/css/morecotation.html/logospecial.html'
    })
}

let btn2 = document.getElementById('signup2')
if (btn2) {
    btn2.addEventListener('click', () => {
        location.href = "/css/morecotation.html/logoplus.html"
    })
}

let btn3 = document.getElementById('signup3')
if (btn3) {
    btn3.addEventListener("click", () => {
        location.href = "/css/morecotation.html/logoplatinum.html"
    })
}

let btn4 = document.getElementById('btn4')
if (btn4) {

    btn4.addEventListener('click', () => {
        location.href = "/css/morecotation.html/logoinfinite.html"
    })
}

let signup5 = document.getElementById('signup5')
if (signup5) {

    signup5.addEventListener('click', () => {
        location.href = "/css/morecotation.html/mascotlogo.html"
    })
}

let signup6 = document.getElementById('signup6')
if (signup6) {

    signup6.addEventListener('click', () => {
        location.href = "/css/morecotation.html/3Dlogo.html"
    })
}

let button = document.querySelector('#btnview')
if (button) {
    button.addEventListener('click', () => {
        location.href = "/css/morecotation.html/learnmore.html"
    })
}

const subscribe = document.getElementById('subscribe-btn')
if (subscribe) {
    subscribe.addEventListener('click', () => {
        location.href = 'signup.html'
    })
}


const subscribec = document.getElementById('subscribe')
if (subscribec) {
    subscribec.addEventListener('click', () => {
        location.href = 'signup.html'
    })
}
